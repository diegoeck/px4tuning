# px4tuning

Data-driven controller tuning for UAV firmware PX4
--------------------------------------------------

## Install:

pip instal px4tuning

## Use:

px4att file.ulg --plot
